package com.cg.paytm.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.BeforeClass;

import com.cg.paytm.bean.Customer;
import com.cg.paytm.bean.Trans;
import com.cg.paytm.exception.PaytmException;
import com.cg.paytm.service.IPaytmService;
import com.cg.paytm.service.PaytmServiceImpl;

public class Test1 {

	private static IPaytmService service;

	@BeforeClass
	public static void createInstance() {
		service = new PaytmServiceImpl();
	}

	@org.junit.Test
	public void testCreateAccountPositive() throws PaytmException {
		Customer customer = new Customer();
		customer.setFirstName("rohini");
		customer.setLastName("thunuguntla");
		customer.setPhnNo(9059900989l);
		customer.setAdharNo(355960351676l);
		customer.setMail("rohini6rani@gmail.com");
		customer.setPin(1234);
		boolean res = service.validate(customer);
		assertTrue(res);
	}

	@org.junit.Test(expected = PaytmException.class)
	public void testCreateAccountForFirstNameLength() throws PaytmException {
		Customer customer = new Customer();
		customer.setFirstName("ro");
		customer.setLastName("thunuguntla");
		customer.setPhnNo(9059900989l);
		customer.setAdharNo(355960351676l);
		customer.setMail("rohini6rani@gmail.com");
		customer.setPin(1234);
		service.validate(customer);
	}

	@org.junit.Test(expected = PaytmException.class)
	public void testCreateAccountForLastNameLength() throws PaytmException {
		Customer customer = new Customer();
		customer.setFirstName("rohini");
		customer.setLastName("th");
		customer.setPhnNo(9059900989l);
		customer.setAdharNo(355960351676l);
		customer.setMail("rohini6rani@gmail.com");
		customer.setPin(1234);
		service.validate(customer);
	}

	@org.junit.Test(expected = PaytmException.class)
	public void testCreateAccountLastNameFornumbers() throws PaytmException {
		Customer customer = new Customer();
		customer.setFirstName("rohini");
		customer.setLastName("thunugu123ntla");
		customer.setPhnNo(9059900989l);
		customer.setAdharNo(355960351676l);
		customer.setMail("rohini6rani@gmail.com");
		customer.setPin(1234);
		service.validate(customer);
	}

	@org.junit.Test(expected = PaytmException.class)
	public void testCreateAccountForFirstNameFornumbers() throws PaytmException {
		Customer customer = new Customer();
		customer.setFirstName("rohi123ni");
		customer.setLastName("thunuguntla");
		customer.setPhnNo(9059900989l);
		customer.setAdharNo(355960351676l);
		customer.setMail("rohini6rani@gmail.com");
		customer.setPin(1234);
		service.validate(customer);
	}

	@org.junit.Test(expected = PaytmException.class)
	public void testCreateAccountForPhnNoLength() throws PaytmException {
		Customer customer = new Customer();
		customer.setFirstName("rohini");
		customer.setLastName("thunuguntla");
		customer.setPhnNo(90599009l);
		customer.setAdharNo(355960351676l);
		customer.setMail("rohini6rani@gmail.com");
		customer.setPin(1234);
		service.validate(customer);
	}

	@org.junit.Test(expected = PaytmException.class)
	public void testCreateAccountForAdharNolength() throws PaytmException {
		Customer customer = new Customer();
		customer.setFirstName("rohini");
		customer.setLastName("thunuguntla");
		customer.setPhnNo(9059900989l);
		customer.setAdharNo(3559603516l);
		customer.setMail("rohini6rani@gmail.com");
		customer.setPin(1234);
		service.validate(customer);
	}

	@org.junit.Test(expected = PaytmException.class)
	public void testCreateAccountForEmail() throws PaytmException {
		Customer customer = new Customer();
		customer.setFirstName("rohini");
		customer.setLastName("thunuguntla");
		customer.setPhnNo(9059900989l);
		customer.setAdharNo(355960351676l);
		customer.setMail("rohini6ranigmail.com");
		customer.setPin(1234);
		service.validate(customer);
	}

	@org.junit.Test(expected = PaytmException.class)
	public void testCreateAccountForEmailForLength() throws PaytmException {
		Customer customer = new Customer();
		customer.setFirstName("rohini");
		customer.setLastName("thunuguntla");
		customer.setPhnNo(9059900989l);
		customer.setAdharNo(355960351676l);
		customer.setMail("rohin@gmail.com");
		customer.setPin(1234);
		service.validate(customer);
	}

	@org.junit.Test(expected = PaytmException.class)
	public void testCreateAccountForEmailForMailLength() throws PaytmException {
		Customer customer = new Customer();
		customer.setFirstName("rohini");
		customer.setLastName("thunuguntla");
		customer.setPhnNo(9059900989l);
		customer.setAdharNo(355960351676l);
		customer.setMail("rohini@gil.com");
		customer.setPin(1234);
		service.validate(customer);
	}

	@org.junit.Test(expected = PaytmException.class)
	public void testCreateAccountForEmailForDotcom() throws PaytmException {
		Customer customer = new Customer();
		customer.setFirstName("rohini");
		customer.setLastName("thunuguntla");
		customer.setPhnNo(9059900989l);
		customer.setAdharNo(355960351676l);
		customer.setMail("rohini@gmail");
		customer.setPin(1234);
		service.validate(customer);
	}

	@org.junit.Test
	public void testDeposit() throws PaytmException {
		double amount = 100;
		Long phnNO = 9247144559l;
		double res = service.deposit(amount, phnNO);

		assertEquals(5000, res, 0);

	}

	@org.junit.Test(expected = PaytmException.class)
	public void testDepositforPhnNo() throws PaytmException {
		double amount = 100;
		Long phnNO = 9247144558l;
		service.deposit(amount, phnNO);
	}

	@org.junit.Test
	public void testDepositForNegative() throws PaytmException {
		double amount = -100;
		Long phnNO = 9247144559l;
		double res = service.deposit(amount, phnNO);
		assertEquals(0, res, 0);

	}

	@org.junit.Test
	public void testWithDraw() throws PaytmException {
		double amount = 100;
		Long phnNO = 9247144559l;
		double res = service.withDraw(amount, phnNO);
		assertEquals(4900, res, 0);

	}



	@org.junit.Test
	public void testWithdrawForNegative() throws PaytmException {
		double amount = -100;
		Long phnNO = 9247144559l;
		double res = service.withDraw(amount, phnNO);
		assertEquals(0, res, 0);

	}

	@org.junit.Test(expected = PaytmException.class)
	public void testWithDrawForPhnNo() throws PaytmException {
		double amount = 100;
		Long phnNO = 9247144558l;
		service.withDraw(amount, phnNO);

	}

	@org.junit.Test
	public void testFundsTransfer() throws PaytmException {
		double amount = 100;
		Long phnNO = 9247144559l;
		Long transphnNo = 9396939591l;
		double res = service.fundTransfer(amount, phnNO, transphnNo);
		assertEquals(4900, res, 0);
	}

	@org.junit.Test(expected = PaytmException.class)
	public void testFundsTransferForFirstPhnNo() throws PaytmException {
		double amount = 100;
		Long phnNO = 9247144549l;
		Long transphnNo = 9396939591l;
		service.fundTransfer(amount, phnNO, transphnNo);

	}

	@org.junit.Test(expected = PaytmException.class)
	public void testFundsTransferForSecondPhnNo() throws PaytmException {
		double amount = 100;
		Long phnNO = 9247144559l;
		Long transphnNo = 9396919591l;
		service.fundTransfer(amount, phnNO, transphnNo);
	}

	@org.junit.Test
	public void testFundsTransferForNegative() throws PaytmException {
		double amount = -100;
		Long phnNO = 9247144559l;
		Long transphnNo = 9396939591l;
		double res = service.fundTransfer(amount, phnNO, transphnNo);
		assertEquals(0, res, 0);
	}
	
	@org.junit.Test
	public void testShowBalance(){
		Long phnNO = 9247144559l;
		double res = service.showBalance(phnNO);
		assertEquals(5000, res, 0);
		
	}
	@org.junit.Test
	public void testPrintTransactions(){
		Long phnNO = 9247144559l;
		List<Trans> list= service.printTransactions(phnNO);

		
	}
	
	

}
